# Wafers fault detection -  A real Machine learning project
# Wafers-Fault-Detection
