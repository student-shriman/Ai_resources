﻿# Assignments 5

### Important Notes to follow for doing the assignmnets

1. Use Markdown to create your assignmnets. Use <a href="https://markdownmonster.west-wind.com/" target="_blank">Markdown_Monster</a> or <a href="https://typora.io/" target="_blank">Typora</a> to decorate your documents. 
2. There should be pictures attached to the needed documnets can be internet souce or self made.
3. Mention all the important formula and equations needed as per the topic
4. Upload all the assignments chapterwise/sectionwise.
5. Submit all your assignmnets before deadlines.
6. Write the answers below the specific questions.


## Chapter 5

**Question 1**.Write the names of diffrent CNN architectures available till 2020?(Mininmum 10)

**Question 2**.Diffrence b/w 3x3 and 5x5 kernels

**Question 3**.What are the cons of using Fully Connencted layers at the end of VGG architecture?

**Question 4**.Write down the improvements in VGG over aleXnet?

**Question 5**.Explain the inception block in detail in GoogleNet

**Question 6**.What are residual blocks?

**Question 7**.What sre skip connections?

**Question 8**.What are advantages of using skip connections?