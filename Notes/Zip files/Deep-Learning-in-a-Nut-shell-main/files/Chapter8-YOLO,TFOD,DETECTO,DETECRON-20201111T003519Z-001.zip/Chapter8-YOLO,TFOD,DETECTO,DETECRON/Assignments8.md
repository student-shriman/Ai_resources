﻿# Assignments 8

### Important Notes to follow for doing the assignmnets

1. Use Markdown to create your assignmnets. Use <a href="https://markdownmonster.west-wind.com/" target="_blank">Markdown_Monster</a> or <a href="https://typora.io/" target="_blank">Typora</a> to decorate your documents. 
2. There should be pictures attached to the needed documnets can be internet souce or self made.
3. Mention all the important formula and equations needed as per the topic
4. Upload all the assignments chapterwise/sectionwise.
5. Submit all your assignmnets before deadlines.
6. Write the answers below the specific questions.

## Chapter 8
**Question 1**.What is Yolo?

**Question 2**.Mention the diffrences between Yolo v1 v2 and v3.

**Question 3**.What is Darknet?

**Question 4**.Which is better TFOD API or YOLO? Decide yourself.

**Question 5**.Create a complete setup documentation for TFOD API for multi object detction using custom dataset.(Local Machine)

**Question 6**.Create a complete setup documentation for YOLO for multi object detction using custom dataset.(Local Machine)

**Question 7**.Create a complete setup documentation for Detecto for multi object detction using custom dataset.(Local Machine)

**Question 8**.Create a complete setup documentation for Detectron2 for multi object detction using custom dataset.(Google Colab)
