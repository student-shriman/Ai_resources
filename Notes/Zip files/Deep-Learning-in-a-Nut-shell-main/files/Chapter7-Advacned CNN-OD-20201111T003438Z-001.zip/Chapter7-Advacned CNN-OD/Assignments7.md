﻿# Assignments 7

### Important Notes to follow for doing the assignmnets

1. Use Markdown to create your assignmnets. Use <a href="https://markdownmonster.west-wind.com/" target="_blank">Markdown_Monster</a> or <a href="https://typora.io/" target="_blank">Typora</a> to decorate your documents. 
2. There should be pictures attached to the needed documnets can be internet souce or self made.
3. Mention all the important formula and equations needed as per the topic
4. Upload all the assignments chapterwise/sectionwise.
5. Submit all your assignmnets before deadlines.
6. Write the answers below the specific questions.


## Chapter 7 

**Question 1**.Explain the working of Single shots detectors?

**Question 2**.Mention the major improvements introduced in FasterRCNN over RCNN,FastRCNN.

**Question 3**.Major component of object dtection networks

**Question 4**.What is the output of an object dteetction network?

**Question 5**.How to choose diffrent object detection models for a usecase?

**Question 5**.Why SSD networks are fast?